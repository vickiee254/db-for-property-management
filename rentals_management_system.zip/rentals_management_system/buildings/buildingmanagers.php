<?php
// Include the database connection file
include 'connect.php';

// Query to fetch building manager data
$sql = "SELECT manager_name, building_name, contact_number FROM buildings";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Building Managers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            text-align: center;
            font-size: 2.5em;
            color: #007bff;
            margin-bottom: 20px;
        }
        .container {
            width: 90%;
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>

<h1>Building Managers</h1>

<div class="container">
    <?php if ($result->num_rows > 0) { ?>
        <table>
            <tr>
                <th>Manager Name</th>
                <th>Building Name</th>
                <th>Contact Number</th>
            </tr>
            <?php while($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['manager_name']); ?></td>
                <td><?php echo htmlspecialchars($row['building_name']); ?></td>
                <td><?php echo htmlspecialchars($row['contact_number']); ?></td>
            </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <p>No building managers found.</p>
    <?php } ?>
</div>

<?php
// Close the database connection
$conn->close();
?>

</body>
</html>
