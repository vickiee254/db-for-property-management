<?php
// Database configuration
$host = 'localhost'; // Database host (default for XAMPP)
$dbname = 'rentals_management_system'; // Name of your database
$username = 'root'; // Database username (default for XAMPP)
$password = ''; // Database password (default is empty for XAMPP)

// Create a new connection to the MySQL database
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optional: Set character set to utf8 to support special characters
$conn->set_charset("utf8");
?>
