<?php
// Include database connection
include 'connect.php';
// Include the TCPDF library
require_once('tcpdf/tcpdf.php'); // Adjust the path as necessary

// Create a new PDF document
$pdf = new TCPDF();

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Rentals Management System');
$pdf->SetTitle('List of Buildings');
$pdf->SetSubject('Buildings Data');
$pdf->SetKeywords('TCPDF, PDF, buildings, rentals');

// Set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, 'List of Buildings', 'Generated on: ' . date('Y-m-d'));

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', 'B', 12);

// Title
$pdf->Cell(0, 10, 'Buildings List', 0, 1, 'C');

// Set font for the table
$pdf->SetFont('helvetica', '', 10);

// Table headers
$header = array('Building ID', 'Building Name', 'Address', 'Manager Name', 'Total Units', 'Contact Number');

// Column widths
$w = array(30, 50, 50, 40, 25, 30);

// Header
for ($i = 0; $i < count($header); $i++) {
    $pdf->Cell($w[$i], 10, $header[$i], 1, 0, 'C');
}
$pdf->Ln();

// Fetch buildings data from the database
$sql = "SELECT building_id, building_name, address, manager_name, total_units, contact_number FROM buildings";
$result = $conn->query($sql);

// Data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell($w[0], 10, $row['building_id'], 1);
        $pdf->Cell($w[1], 10, $row['building_name'], 1);
        $pdf->Cell($w[2], 10, $row['address'], 1);
        $pdf->Cell($w[3], 10, $row['manager_name'], 1);
        $pdf->Cell($w[4], 10, $row['total_units'], 1);
        $pdf->Cell($w[5], 10, $row['contact_number'], 1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(0, 10, 'No buildings found.', 1, 1, 'C');
}

// Close and output PDF document
$pdf->Output('buildings_list.pdf', 'D');

// Close the database connection
$conn->close();
?>
