<?php
// Include the database connection file
include 'connect.php';

// Query to fetch buildings data from the database
$sql = "SELECT building_id, building_name, address, manager_name, total_units, contact_number FROM buildings";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Buildings - Rentals Management System</title>
    
    <!-- Font Awesome Library for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background: #007bff;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        h1 {
            margin: 0;
            font-size: 2.5em;
        }
        nav {
            margin: 20px 0;
            text-align: center;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 15px;
            font-size: 1.2em;
        }
        nav a:hover {
            text-decoration: underline;
        }
        .download-icon {
            display: inline-block;
            margin-left: 15px;
            font-size: 1.5em;
            color: #fff;
            cursor: pointer;
            vertical-align: middle;
        }
        .download-icon:hover {
            color: #ccc;
        }
        .container {
            width: 90%;
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .no-data {
            text-align: center;
            font-size: 1.2em;
            color: #ff0000;
        }
        footer {
            text-align: center;
            padding: 10px;
            background: #007bff;
            color: #fff;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<header>
    <h1>List of Buildings</h1>
    <nav>
        <a href="index.html">Home</a>
        <a href="listbuilding.php">List Buildings</a>
        <a href="registerbuilding.php">Register New Building</a>
        <a href="buildingmanagers.php">Building Managers</a>
        <!-- Font Awesome Download Icon -->
        <a href="download.php" class="download-icon" title="Download List">
            <i class="fas fa-download"></i>
        </a>
    </nav>
</header>

<div class="container">
    <?php if ($result->num_rows > 0) { ?>
        <table>
            <thead>
                <tr>
                    <th>Building ID</th>
                    <th>Building Name</th>
                    <th>Address</th>
                    <th>Manager Name</th>
                    <th>Total Units</th>
                    <th>Contact Number</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['building_id']; ?></td>
                        <td><?php echo $row['building_name']; ?></td>
                        <td><?php echo $row['address']; ?></td>
                        <td><?php echo $row['manager_name']; ?></td>
                        <td><?php echo $row['total_units']; ?></td>
                        <td><?php echo $row['contact_number']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <p class="no-data">No buildings found.</p>
    <?php } ?>
</div>

<footer>
    &copy; 2024 Rentals Management System
</footer>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
