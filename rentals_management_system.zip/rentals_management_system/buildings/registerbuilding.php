<?php
// Include the database connection file
include 'connect.php';

// Initialize variables to store form data and error messages
$building_name = $address = $total_units = $manager_name = $contact_number = "";
$error_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize form data
    $building_name = $conn->real_escape_string($_POST['building_name']);
    $address = $conn->real_escape_string($_POST['address']);
    $total_units = (int)$_POST['total_units'];
    $manager_name = $conn->real_escape_string($_POST['manager_name']);
    $contact_number = $conn->real_escape_string($_POST['contact_number']);

    // Validate inputs
    if (empty($building_name) || empty($address) || empty($total_units) || empty($manager_name) || empty($contact_number)) {
        $error_message = "All fields are required!";
    } else {
        // Insert the new building into the database
        $sql = "INSERT INTO buildings (building_name, address, total_units, manager_name, contact_number) 
                VALUES ('$building_name', '$address', $total_units, '$manager_name', '$contact_number')";

        if ($conn->query($sql) === TRUE) {
            // Redirect to index.html after successful submission
            header('Location: index.html');
            exit(); // Stop further execution after redirection
        } else {
            $error_message = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Building</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background: #007bff;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        h1 {
            margin: 0;
            font-size: 2.5em;
        }
        .container {
            width: 90%;
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
            font-size: 1.1em;
        }
        input[type="text"], input[type="number"] {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
        }
        input[type="submit"] {
            margin-top: 20px;
            padding: 10px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1.2em;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background: #218838;
        }
        .error {
            margin-top: 15px;
            font-size: 1.1em;
            color: #ff0000;
        }
        footer {
            text-align: center;
            padding: 10px;
            background: #007bff;
            color: #fff;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<header>
    <h1>Register New Building</h1>
</header>

<div class="container">
    <form action="registerbuilding.php" method="POST">
        <label for="building_name">Building Name</label>
        <input type="text" name="building_name" id="building_name" value="<?php echo $building_name; ?>" required>

        <label for="address">Address</label>
        <input type="text" name="address" id="address" value="<?php echo $address; ?>" required>

        <label for="total_units">Total Units</label>
        <input type="number" name="total_units" id="total_units" value="<?php echo $total_units; ?>" required>

        <label for="manager_name">Manager Name</label>
        <input type="text" name="manager_name" id="manager_name" value="<?php echo $manager_name; ?>" required>

        <label for="contact_number">Contact Number</label>
        <input type="text" name="contact_number" id="contact_number" value="<?php echo $contact_number; ?>" required>

        <input type="submit" value="Register Building">
    </form>

    <?php if (!empty($error_message)) { ?>
        <p class="error"><?php echo $error_message; ?></p>
    <?php } ?>
</div>

<footer>
    &copy; 2024 Rentals Management System
</footer>

</body>
</html>
